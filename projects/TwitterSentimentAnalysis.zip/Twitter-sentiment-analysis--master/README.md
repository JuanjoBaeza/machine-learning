# Twitter-sentiment-analysis-

# Intro-

This project will just takes tweets of whatever hashtag u want to search  and output a pie chart containing neutral tweets,positive tweets,negative tweets.
and all information about the tweets and its sentiment will be stored in the file.


# requirements-

1. tweepy 

2. Matplotlib

3. Collections

4. aylienapiclient (For this you have to make account )


# How to run :

Just type ....python3 mymain.py(So simple)

Before running project ,ensure that you have installed all the required libraries of python .





